package Coty;

import java.util.ArrayList;

public class TarjetaDebito extends MetodoPago{

	@Override
	public void CalcularPago(ArrayList<Producto> listProductos, int cuotas) {
		// TODO Auto-generated method stub
		
	}

}
